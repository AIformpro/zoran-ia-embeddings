from ziae.core import ZoranIAEmbeddings
import numpy as np

def test_embed_shape():
    model = ZoranIAEmbeddings()
    data = ["a", "b", "c"]
    emb = model.embed(data)
    assert emb.shape[0] == len(data)
