from ziae.core import ZoranIAEmbeddings

model = ZoranIAEmbeddings()
data = ["ex1", "ex2", "ex3"]
embeddings = model.embed(data)
print("Embeddings shape:", embeddings.shape)

# Exemple d'évaluation bidon
labels_true = [0, 1, 0]
labels_pred = [0, 0, 1]
print(model.evaluate(labels_true, labels_pred))
